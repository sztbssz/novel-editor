# LoRA多风格小说生成训练

4风格LoRA模型训练包，适用于RTX 5070 (12GB/16GB)。

## 📋 训练流程

### 1. 安装环境

在本地5070机器上执行:

```bash
cd lora-training
bash scripts/install_env.sh
```

安装内容:
- Miniconda (如未安装)
- Python 3.11
- PyTorch 2.3 + CUDA 12.1
- LoRA训练工具 (peft, transformers, accelerate)
- 数据收集工具

### 2. 收集训练数据

```bash
conda activate lora-train
python scripts/data_collect.py
```

这会生成示例训练数据。建议替换为真实小说内容:
- 每个风格至少20条样本
- 每条500-1000字
- 数据来源: 起点免费章节、作者自备稿件等

### 3. 开始训练

**训练所有风格 (推荐):**
```bash
python scripts/train.py --style all
```

**单独训练某个风格:**
```bash
python scripts/train.py --style funny      # 搞笑风格
python scripts/train.py --style xuanhuan   # 玄幻风格
python scripts/train.py --style horror     # 恐怖风格
python scripts/train.py --style modern     # 现代风格
```

**训练参数说明:**
- 基础模型: Qwen2.5-7B-Instruct
- LoRA rank: 16
- 学习率: 1e-4
- 训练轮数: 3
- batch_size: 1 (5070 12GB)
- 4bit量化: 开启 (节省显存)
- 预计时间: 1.5-2小时/风格

### 4. 使用模型生成

**交互模式:**
```bash
python scripts/generate.py
```

**命令行模式:**
```bash
python scripts/generate.py --style funny --prompt "主角醒来发现自己"
```

## 📁 目录结构

```
lora-training/
├── scripts/
│   ├── install_env.sh    # 环境安装脚本
│   ├── data_collect.py   # 数据收集脚本
│   ├── train.py          # 训练脚本
│   └── generate.py       # 推理脚本
├── configs/              # 配置文件 (可选)
├── data/                 # 训练数据
│   ├── funny_train.json
│   ├── xuanhuan_train.json
│   ├── horror_train.json
│   └── modern_train.json
└── outputs/              # 训练输出
    ├── lora_funny/
    ├── lora_xuanhuan/
    ├── lora_horror/
    └── lora_modern/
```

## 🎨 4种风格说明

| 风格 | 代表作品 | 特点 |
|------|---------|------|
| funny | 《大王饶命》《修真聊天群》 | 搞笑、系统流、轻松幽默 |
| xuanhuan | 《大奉打更人》《我不是戏神》 | 玄幻、修仙、志怪 |
| horror | 《神秘复苏》《地狱公寓》 | 恐怖、悬疑、诡异 |
| modern | 《间客》《从红月开始》 | 现代、科幻、都市异能 |

## ⚙️ 训练参数调优

如遇到显存不足:
```python
# 减小batch_size
per_device_train_batch_size=1

# 增大梯度累积
gradient_accumulation_steps=8

# 减小max_length
max_length=512
```

如训练效果不佳:
```python
# 增加训练轮数
num_train_epochs=5

# 调整学习率
learning_rate=5e-5

# 增大LoRA rank
r=32
lora_alpha=64
```

## 🔧 故障排除

**问题: CUDA out of memory**
- 解决方案: 开启4bit量化已默认启用，如仍不足可减小max_length到512

**问题: 模型下载失败**
- 解决方案: 设置HF镜像 `export HF_ENDPOINT=https://hf-mirror.com`

**问题: 训练速度慢**
- 正常现象: 7B模型+LoRA在5070上约1.5-2小时/风格
- 优化: 确保CUDA正确安装，使用nvidia-smi查看GPU利用率

## 📊 训练监控

训练过程中会输出:
- Loss值 (应逐渐下降)
- 学习率变化
- 已训练步数/总步数
- 预计剩余时间

## 📝 数据格式

训练数据JSON格式:
```json
[
  {
    "instruction": "请以搞笑风格续写以下小说内容",
    "input": "",
    "output": "吕树看着系统面板一脸懵逼...",
    "style": "搞笑风格"
  }
]
```

## 🎯 下一步计划

1. 收集更多真实小说数据替换示例数据
2. 训练完成后测试各风格生成效果
3. 集成到创世者编辑器中
4. 考虑增加更多风格 (言情、历史、军事等)

## 📚 参考

- [PEFT文档](https://huggingface.co/docs/peft)
- [LoRA论文](https://arxiv.org/abs/2106.09685)
- [Qwen2.5模型](https://huggingface.co/Qwen)
